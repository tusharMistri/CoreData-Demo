//
//  AddViewController.m
//  coreData-demo
//
//  Created by Tushar on 12/11/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import "AddViewController.h"



@interface AddViewController ()

@end

@implementation AddViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    if (self.contactdb) {
        [txtname setText:[self.contactdb valueForKey:@"name"]];
        [txtCompany setText:[self.contactdb valueForKey:@"company"]];
        [txtversion setText:[self.contactdb valueForKey:@"version"]];
    }

    
}



- (NSManagedObjectContext *)managedObjectContext {
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}


#pragma mark - UIbutton Action Methods

-(IBAction)buttonClickSave:(UIButton *)sender
{
    NSString *strname = txtname.text;
    NSString *strcompany = txtCompany.text;
    NSString *strversion = txtversion.text;
    
    
    NSManagedObjectContext *context = [self managedObjectContext];
    
    if (self.contactdb) {
        // Update existing device
        [self.contactdb setValue:strname forKey:@"name"];
        [self.contactdb setValue:strcompany forKey:@"company"];
        [self.contactdb setValue:strversion forKey:@"version"];
        
    } else {
        // Create a new device
        NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Device" inManagedObjectContext:context];
        [newDevice setValue:strname forKey:@"name"];
        [newDevice setValue:strcompany forKey:@"company"];
        [newDevice setValue:strversion forKey:@"version"];
    }
    NSError *error = nil;
    // Save the object to persistent store
    if (![context save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)buttonClickCancel:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Extra Methods

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
