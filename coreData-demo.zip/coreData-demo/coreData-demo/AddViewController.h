//
//  AddViewController.h
//  coreData-demo
//
//  Created by Tushar on 12/11/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AddViewController : UIViewController
{
    IBOutlet UITextField *txtname;
    IBOutlet UITextField *txtCompany;
    IBOutlet UITextField *txtversion;
}

@property (strong) NSManagedObject *contactdb;

@end
