//
//  ViewDetailsController.m
//  coreData-demo
//
//  Created by Tushar on 12/11/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import "ViewDetailsController.h"

@interface ViewDetailsController ()

@end

@implementation ViewDetailsController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewDidAppear:(BOOL)animated
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Device"];
    self.devices = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    NSLog(@"self.devices : %@",self.devices);
    [objtableview reloadData];
}

- (NSManagedObjectContext *)managedObjectContext
{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}

#pragma mark - tableview dataSource

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    
    NSManagedObject *device = [self.devices objectAtIndex:indexPath.row];
    
    [cell.detailTextLabel setText:[device valueForKey:@"company"]];
    [cell.textLabel setText:[NSString stringWithFormat:@"%@ %@", [device valueForKey:@"name"],[device valueForKey:@"version"]]];
    
    return  cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.devices.count;
}

#pragma mark - tableview delegate

#pragma mark - UIButton Action Methdos

-(IBAction)buttonClickAdd:(UIButton *)sender
{
    AddViewController *objAddVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AddViewController"];
    [self.navigationController pushViewController:objAddVC animated:YES];
}

#pragma mark - Extra Methdos

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

@end
