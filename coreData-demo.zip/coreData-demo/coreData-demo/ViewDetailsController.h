//
//  ViewDetailsController.h
//  coreData-demo
//
//  Created by Tushar on 12/11/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AddViewController.h"
#import <CoreData/CoreData.h>

@interface ViewDetailsController : UIViewController <UITableViewDataSource>
{
    IBOutlet UITableView *objtableview;
}

@property (strong) NSMutableArray *devices;

@end
